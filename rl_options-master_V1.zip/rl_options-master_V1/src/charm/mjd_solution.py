import numpy as np
import scipy.stats as si
from scipy.special import factorial
from matplotlib import pyplot as plt

def bs(S, K, T, r, sigma):
    d1 = (np.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
    d2 = (np.log(S / K) + (r - 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
            
    delta = si.norm.cdf(d1)
    call = (S * si.norm.cdf(d1, 0.0, 1.0) - K * np.exp(-r * T) * si.norm.cdf(d2, 0.0, 1.0))
                    
    return call, delta


def mjd(S, K, T, r, sigma, Lambda, a, b, N=100):
    kappa = np.exp(a + 0.5 * b**2) - 1
    lambda_bar = Lambda * (1 + kappa)
    sigma_i = np.sqrt(np.full(N, sigma**2) + np.arange(N) / T * b**2)
    r_i = np.full(N, r) - Lambda * kappa + np.arange(N) * np.log(1 + kappa) / T
    poisson_pmf = np.multiply(np.exp(np.full(N, -1 * lambda_bar * T)), (lambda_bar * T) ** np.arange(N)) / factorial(np.arange(N))

    S = np.array([S,] * N).T
    call, delta = np.dot(bs(S, K, T, r_i, sigma_i), poisson_pmf)
    
    return call, delta

S = np.arange(80, 130)
K = 100
T = 90/250
r = 0
sigma = 0.15
Lambda = 10
a = 0.04
b = 0.01
N = 50

print(mjd(S, K, T, r, sigma, Lambda, a, b, N))
print(bs(S, K, T, r, sigma))

print(mjd(S, K, T, r, sigma, Lambda, a, b))
plt.figure()
plt.plot(S, mjd(S, K, T, r, sigma, Lambda, a, b)[0])
plt.plot(S, bs(S, K, T, r, sigma)[0])
plt.figure()
plt.plot(S, mjd(S, K, T, r, sigma, Lambda, a, b)[1])
plt.plot(S, bs(S, K, T, r, sigma)[1])
plt.show()
