import os
import tensorflow as tf
from matplotlib import pyplot as plt
import numpy as np
import scipy.stats as si
from mjd_solution import *

def bs(S, K, T, r, sigma):
	d1 = (np.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
	d2 = (np.log(S / K) + (r - 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
	print(np.log(S/K).shape) 
	delta = si.norm.cdf(d1)
	call = (S * si.norm.cdf(d1, 0.0, 1.0) - K * np.exp(-r * T) * si.norm.cdf(d2, 0.0, 1.0))
	gamma = si.norm.pdf(d1) / (S * sigma * np.sqrt(T))
	theta = - (S * sigma * si.norm.pdf(d1)) / (2 * np.sqrt(T)) - r * K * np.exp(-r * T) * si.norm.cdf(d2)   
	charm = si.norm.pdf(d1) * d2 / (2 * T)
                 
	return call, delta, gamma, theta, charm


if not os.path.isdir('results'):
    os.makedirs('results')

model = tf.keras.models.load_model('model.h5')
print("Model restored.")
model.summary()

K=100
T=100

# Cost graph
X_train = np.ones((10000,3))
X_train[:, 0] = np.linspace(80, 130, num=10000)
X_train[:, 1] *= K
X_train[:, 2] *= T
#X_train[:, 2] *= 0

call, delta, gamma, theta, charm = bs(X_train[:,0], K, T, 0, .07425)

#calculate C, delta, gamma, theta using model
r = tf.fill([tf.shape(input=X_train)[0],1], 0., name = 'r') # interest rate, if applicable

S = tf.cast(tf.slice(X_train, (0,0), (-1,1)), tf.float32)
K = tf.cast(tf.slice(X_train, (0,1), (-1,1)), tf.float32)
T = tf.cast(tf.slice(X_train, (0,2), (-1,1)), tf.float32)

with tf.GradientTape() as tape0:
    tape0.watch(T)
    with tf.GradientTape() as tape1:
            tape1.watch(S)
            with tf.GradientTape() as tape2:
                    tape2.watch([S, T])
                    X = tf.concat([S/(K*tf.exp(-r*T)), T], 1) #input matrix for ANN

                    out = model(X, training=False)
                    out_values = K*tf.where(tf.greater(T, 1e-3), out, tf.maximum(S/K - 1, 0))
            delta_values, theta_values = tape2.gradient(out_values, [S, T])
    gamma_values = tape1.gradient(delta_values, S)
charm_values = tape0.gradient(delta_values, T)

print(tf.executing_eagerly())
out_values = out_values.numpy()
delta_values = delta_values.numpy()
theta_values = theta_values.numpy()
gamma_values = gamma_values.numpy()
theta_values = - theta_values
charm_values = - charm_values.numpy()

print("max:", out_values.max(), "min:", out_values.min())
plt.figure()
plt.plot(X_train[:,0], out_values, label = 'Reinforcement ANN')
plt.plot(X_train[:,0], call, label = 'Black-Scholes')
plt.legend()
plt.title('With Charm Before Tuning \n Estimated option prices for given underlying asset prices')
plt.xlabel('S')
plt.ylabel('C')
plt.savefig('results/c.png')

plt.figure()
plt.title('With Charm Before Tuning \n Estimated delta values for given underlying asset prices')
plt.xlabel('S')
plt.ylabel('Delta, ∆')
plt.plot(X_train[:,0], delta_values, label = 'Reinforcement ANN')
plt.plot(X_train[:,0], delta, label = 'Black-Scholes')
plt.legend()
plt.savefig('results/d.png')

plt.figure()
plt.title('With Charm Before Tuning \n Estimated gamma values for given underlying asset prices')
plt.xlabel('S')
plt.ylabel('Gamma')
plt.plot(X_train[:,0], gamma_values, label = 'Reinforcement ANN')
plt.plot(X_train[:,0], gamma, label = 'Black-Scholes')
plt.legend()
plt.savefig('results/gamma.png')

plt.figure()
plt.title('With Charm Before Tuning \n Estimated theta values for given underlying asset prices')
plt.xlabel('S')
plt.ylabel('Theta')
plt.plot(X_train[:,0], theta_values, label = 'Reinforcement ANN')
plt.plot(X_train[:,0], theta, label = 'Black-Scholes')
plt.legend()
plt.savefig('results/theta.png')

plt.figure()
plt.title('With Charm Before Tuning \n Estimated charm values for given underlying asset prices')
plt.xlabel('S')
plt.ylabel('Charm')
plt.plot(X_train[:,0], charm_values, label = 'Reinforcement ANN')
plt.plot(X_train[:,0], charm, label = 'Black-Scholes')
plt.legend()
plt.savefig('results/charm.png')

S = 100
K = 100
T = 100

# Cost graph
X_train = np.ones((10000,3))
X_train[:, 0] *= S
X_train[:, 1] *= K
X_train[:, 2] = np.linspace(1e-2, 1, num=10000)
#X_train[:, 2] *= 0

call, delta, gamma, theta, charm = bs(S, K, X_train[:,2], 0, .1114)

#calculate C, delta, gamma, theta using model
r = tf.fill([tf.shape(input=X_train)[0],1], 0., name = 'r') # interest rate, if applicable

S = tf.cast(tf.slice(X_train, (0,0), (-1,1)), tf.float32)
K = tf.cast(tf.slice(X_train, (0,1), (-1,1)), tf.float32)
T = tf.cast(tf.slice(X_train, (0,2), (-1,1)), tf.float32)

with tf.GradientTape() as tape0:
    tape0.watch(T)
    with tf.GradientTape() as tape1:
            tape1.watch(S)
            with tf.GradientTape() as tape2:
                    tape2.watch([S, T])
                    X = tf.concat([S/(K*tf.exp(-r*T)), T], 1) #input matrix for ANN

                    out = model(X, training=False)
                    out_values = K*tf.where(tf.greater(T, 1e-3), out, tf.maximum(S/K - 1, 0))
            delta_values, theta_values = tape2.gradient(out_values, [S, T])
    gamma_values = tape1.gradient(delta_values, S)
charm_values = tape0.gradient(delta_values, T)

out_values = out_values.numpy()
theta_values = - theta_values.numpy()
charm_values = - charm_values.numpy()

plt.figure()
plt.title('With Charm Before Tuning \n Estimated option prices for given expiry')
plt.xlabel('T')
plt.ylabel('C')
plt.plot(X_train[:,2], out_values, label = 'Reinforcement ANN')
plt.plot(X_train[:,2], call, label = 'Black-Scholes')
plt.legend()
plt.savefig('results/C_T.png')

plt.figure()
plt.title('With Charm Before Tuning \n Estimated theta values for given expiry')
plt.xlabel('T')
plt.ylabel('Theta')
plt.plot(X_train[:,2], theta_values, label = 'Reinforcement ANN')
plt.plot(X_train[:,2], theta, label = 'Black-Scholes')
plt.legend()
plt.savefig('results/theta_T.png')

plt.figure()
plt.title('With Charm Before Tuning \n Estimated charm values for given expiry')
plt.xlabel('T')
plt.ylabel('Charm')
plt.plot(X_train[:,2], charm_values, label = 'Reinforcement ANN')
plt.plot(X_train[:,2], charm, label = 'Black-Scholes')
plt.legend()
plt.savefig('results/charm_T.png')
